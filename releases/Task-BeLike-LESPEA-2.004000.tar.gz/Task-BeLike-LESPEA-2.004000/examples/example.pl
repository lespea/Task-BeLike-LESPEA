use strict;
use warnings;

print "Install Task::BeLike::LESPEA via one of the CPAN modules to install all of the modules that I use\n";
